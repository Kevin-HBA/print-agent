// Content Script - Se inyecta en todas las páginas web
// Funciona AUTOMÁTICAMENTE sin necesidad de modificar los proyectos

(function() {
    'use strict';
    
    let agentAvailable = false;
    
    // Verificar si el agente está disponible
    function checkAgent() {
        chrome.runtime.sendMessage({ action: 'checkAgent' }, (response) => {
            agentAvailable = response && response.available;
            if (agentAvailable) {
                console.log('Agente de impresión local disponible');
            }
        });
    }
    
    // Función para imprimir usando el agente
    function printWithAgent(url) {
        if (!agentAvailable) {
            // Si el agente no está disponible, comportamiento normal
            return false;
        }
        
        chrome.runtime.sendMessage(
            { action: 'print', url: url },
            (response) => {
                if (response && response.status === 'ok') {
                    console.log('Documento enviado a la impresora automáticamente');
                    showNotification('Documento enviado a la impresora', 'success');
                } else {
                    // Si falla, comportamiento normal del navegador
                    return false;
                }
            }
        );
        return true;
    }
    
    // Mostrar notificación simple
    function showNotification(message, type) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#4CAF50' : '#2196F3'};
            color: white;
            padding: 15px 20px;
            border-radius: 5px;
            z-index: 10000;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            font-family: Arial, sans-serif;
            font-size: 14px;
        `;
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
    
    // Detectar si una URL es un documento imprimible
    function isPrintableDocument(url) {
        if (!url) return false;
        const urlLower = url.toLowerCase();
        return urlLower.endsWith('.pdf') || 
               urlLower.endsWith('.html') || 
               urlLower.endsWith('.htm') ||
               urlLower.includes('/pdf') ||
               urlLower.includes('/imprimir') ||
               urlLower.includes('/print') ||
               urlLower.includes('content-type=application/pdf');
    }
    
    // Interceptar TODOS los clics en enlaces que sean documentos imprimibles
    document.addEventListener('click', function(e) {
        let target = e.target;
        
        // Buscar el enlace más cercano
        while (target && target.tagName !== 'A' && target.tagName !== 'BUTTON') {
            target = target.parentElement;
        }
        
        if (!target) return;
        
        // Obtener URL del enlace
        let url = null;
        if (target.tagName === 'A') {
            url = target.href;
        } else if (target.tagName === 'BUTTON') {
            // Buscar si el botón tiene un data-url, onclick con URL, o está dentro de un form
            url = target.getAttribute('data-url') || 
                  target.getAttribute('data-href') ||
                  target.getAttribute('onclick')?.match(/https?:\/\/[^\s'"]+/)?.[0];
        }
        
        // Si es un documento imprimible, interceptar
        if (url && isPrintableDocument(url)) {
            // Verificar si el clic es para imprimir (no para descargar)
            const isDownload = target.hasAttribute('download') || 
                              target.getAttribute('target') === '_blank' ||
                              e.ctrlKey || e.metaKey;
            
            // Si no es descarga explícita, interceptar para imprimir
            if (!isDownload && agentAvailable) {
                e.preventDefault();
                e.stopPropagation();
                printWithAgent(url);
                return false;
            }
        }
    }, true); // Usar capture phase para interceptar antes
    
    // Interceptar window.print() - cuando la aplicación llama a imprimir
    const originalPrint = window.print;
    window.print = function() {
        // Intentar obtener URL del documento actual si es un PDF
        if (window.location.href.toLowerCase().endsWith('.pdf')) {
            if (agentAvailable && printWithAgent(window.location.href)) {
                return; // Ya se envió al agente
            }
        }
        // Si no es PDF o agente no disponible, comportamiento normal
        originalPrint.call(window);
    };
    
    // Interceptar apertura de PDFs en nueva ventana
    const originalOpen = window.open;
    window.open = function(url, target, features) {
        if (url && isPrintableDocument(url) && agentAvailable) {
            // Si es un documento imprimible y el agente está disponible, imprimir directamente
            if (printWithAgent(url)) {
                return null; // No abrir ventana
            }
        }
        // Comportamiento normal
        return originalOpen.call(window, url, target, features);
    };
    
    // Interceptar fetch/XMLHttpRequest para detectar peticiones de PDFs
    const originalFetch = window.fetch;
    window.fetch = function(...args) {
        const url = args[0];
        const result = originalFetch.apply(this, args);
        
        // Si es una petición a un PDF
        if (typeof url === 'string' && isPrintableDocument(url) && agentAvailable) {
            result.then(response => {
                const contentType = response.headers.get('content-type') || '';
                if (contentType.includes('pdf') || contentType.includes('application/pdf')) {
                    // Es un PDF, interceptar para imprimir
                    response.clone().blob().then(blob => {
                        // Crear URL temporal del blob
                        const blobUrl = URL.createObjectURL(blob);
                        // Intentar imprimir
                        if (printWithAgent(blobUrl)) {
                            // Si se imprimió, no hacer nada más
                            setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
                        }
                    }).catch(() => {});
                }
                return response;
            }).catch(() => {});
        }
        
        return result;
    };
    
    // Interceptar XMLHttpRequest también
    const originalXHROpen = XMLHttpRequest.prototype.open;
    const originalXHRSend = XMLHttpRequest.prototype.send;
    
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
        this._url = url;
        return originalXHROpen.apply(this, [method, url, ...rest]);
    };
    
    XMLHttpRequest.prototype.send = function(...args) {
        if (this._url && isPrintableDocument(this._url) && agentAvailable) {
            this.addEventListener('load', function() {
                const contentType = this.getResponseHeader('content-type') || '';
                if (contentType.includes('pdf') || contentType.includes('application/pdf')) {
                    const blob = new Blob([this.response], { type: 'application/pdf' });
                    const blobUrl = URL.createObjectURL(blob);
                    if (printWithAgent(blobUrl)) {
                        setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
                    }
                }
            });
        }
        return originalXHRSend.apply(this, args);
    };
    
    // Interceptar descargas de archivos
    document.addEventListener('click', function(e) {
        const target = e.target;
        if (target.tagName === 'A' && target.hasAttribute('download')) {
            const href = target.getAttribute('href');
            if (href && isPrintableDocument(href) && agentAvailable) {
                e.preventDefault();
                e.stopPropagation();
                if (printWithAgent(href)) {
                    return false;
                }
            }
        }
    }, true);
    
    // Interceptar creación de elementos <a> con download
    const originalCreateElement = document.createElement;
    document.createElement = function(tagName, ...args) {
        const element = originalCreateElement.call(this, tagName, ...args);
        if (tagName.toLowerCase() === 'a' && agentAvailable) {
            const originalSetAttribute = element.setAttribute;
            element.setAttribute = function(name, value) {
                originalSetAttribute.call(this, name, value);
                if (name === 'href' && isPrintableDocument(value) && this.hasAttribute('download')) {
                    this.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        printWithAgent(value);
                        return false;
                    }, true);
                }
            };
        }
        return element;
    };
    
    // Interceptar eventos de impresión personalizados (por si acaso)
    window.addEventListener('print-agent-print', function(e) {
        if (e.detail && e.detail.url) {
            printWithAgent(e.detail.url);
        }
    });
    
    // Exponer función global (opcional, para compatibilidad)
    window.printAgent = {
        print: function(url) {
            printWithAgent(url);
        },
        check: function() {
            return new Promise((resolve) => {
                chrome.runtime.sendMessage({ action: 'checkAgent' }, (response) => {
                    resolve(response && response.available);
                });
            });
        }
    };
    
    // Verificar agente al cargar y periódicamente
    checkAgent();
    setInterval(checkAgent, 30000); // Verificar cada 30 segundos
    
    console.log('Agente de Impresión Local: Extensión activa - Modo automático');
})();

