// Service Worker - Escucha peticiones del content script
const AGENT_URL = 'http://localhost:8765';
const AGENT_TOKEN = 'ixj17zpiaFvy9CAccxYyM27LNpDnzMg__M0vLCiqRLI'; // Token de autenticación

// Verificar si el agente está disponible
async function checkAgentHealth() {
    try {
        const response = await fetch(`${AGENT_URL}/health`, {
            method: 'GET',
            timeout: 2000
        });
        const data = await response.json();
        return data.status === 'ok';
    } catch (error) {
        return false;
    }
}

// Imprimir documento usando el agente local
async function printDocument(documentUrl) {
    try {
        const response = await fetch(`${AGENT_URL}/print`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${AGENT_TOKEN}`
            },
            body: JSON.stringify({
                document_url: documentUrl
            }),
            timeout: 30000
        });
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error al imprimir:', error);
        return {
            status: 'error',
            message: 'El agente de impresión no está disponible'
        };
    }
}

// Escuchar mensajes del content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'print') {
        printDocument(request.url).then(result => {
            sendResponse(result);
        });
        return true; // Mantener el canal abierto para respuesta asíncrona
    }
    
    if (request.action === 'checkAgent') {
        checkAgentHealth().then(isAvailable => {
            sendResponse({ available: isAvailable });
        });
        return true;
    }
});

// Verificar agente al iniciar
checkAgentHealth().then(isAvailable => {
    console.log('Agente disponible:', isAvailable);
});

